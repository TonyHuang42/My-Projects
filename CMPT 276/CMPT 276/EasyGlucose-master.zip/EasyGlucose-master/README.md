# EasyGlucose

Welcome! 

This is the initial documentation for our app. We will be documenting our classes and important functions in this readme.

Please only push your code to this repo if it builds without any warnings or error. DO NOT push if the build fails.


Steps:

1) Pull this to your local computer
2) Install cocoapods
  - Locate the application folder from the Terminal
  - enter the 'pod install' command
  - always open the .xcworkspace file, NOT the .xcodeproj
3) begin coding!

Consider creating a branch to do your programming on. If there are any problems with your code, can simply delete the branch and start anew.

For Realm => https://realm.io/docs/swift/latest/ this is extremely helpful!
