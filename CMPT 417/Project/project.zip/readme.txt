game.idp
game.mzn
readme.txt
report.pdf